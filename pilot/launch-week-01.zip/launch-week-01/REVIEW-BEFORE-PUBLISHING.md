# PE / Under scrutiny — week 01

**No post is approved or scheduled. Source URLs are reference candidates; source pages could not be retrieved in this workspace. Verify the precise supporting passages before publication. No claim of legal advice or a current agency position is made.**

Seven days are a suggested sequence, not scheduled dates. Default posting target: 9 p.m. America/New_York. Set the date and time yourself in Meta Business Suite.

Review the exact JPEG and caption, verify supporting sources, make edits, then upload and schedule manually. No files in this kit grant approval or trigger publication.

## Day 1 — Your local store. Someone else's exit strategy?

Files: `01-w01-01.jpg`, `01-w01-01-caption.txt`

Format: editorial_question. Hypothesis: A clear mission and a concrete question will prompt relevant comments.

Approval: **not approved**. Sources: editorial / methodological draft; no external factual example asserted.

Opinion: A business should be judged by how it serves customers and treats workers—not just the price its owners can sell it for.

That is the question behind this account: when investors buy a business, who benefits, who takes the risk, and what happens to the people who depend on it?

We will scrutinize private equity using documents, clear explanations and corrections when the evidence changes. An acquisition alone does not prove wrongdoing.

What industry should we examine first: housing, healthcare or everyday services?

#PrivateEquity #WorkersRights #ConsumerRights

Before publication:

- [ ] This is an editorial statement of values, not a claim about a specific transaction.
- [ ] Do not describe this new account as having already investigated companies.
- [ ] Review graphic, caption and final source links.
- [ ] Approve the final version and manually schedule it.

## Day 2 — Buying a business with borrowed money: who carries the debt?

Files: `02-w01-02.jpg`, `02-w01-02-caption.txt`

Format: mechanism_explainer. Hypothesis: A practical financing checklist will earn saves.

Approval: **not approved**. Sources: **not retrieved; verify before publication**.

A leveraged buyout uses borrowing to help finance an acquisition. The important follow-up question is where that debt sits and which business must service it. Deal structures differ.

Debt payments can compete with other uses of cash. That creates questions worth investigating—not proof that a particular acquisition caused layoffs, higher prices or worse service.

Before accepting an owner's success story, ask: how much debt was added, who is responsible for it, and what changed in investment, staffing and service?

Opinion: Customers and workers deserve answers alongside investors.

Save this checklist for the next buyout headline.

#PrivateEquity #FinancialLiteracy #ConsumerRights

Source reference (review before publishing):
https://www.gao.gov/products/gao-08-885

Before publication:

- [ ] Verify the definition of leveraged buyout and debt servicing using an authoritative finance source.
- [ ] Keep the language conditional: financing structures vary, and debt does not establish harm in an individual case.
- [ ] Review graphic, caption and final source links.
- [ ] Approve the final version and manually schedule it.

## Day 3 — Different signs. The same owner?

Files: `03-w01-03.jpg`, `03-w01-03-caption.txt`

Format: competition_explainer. Hypothesis: A concrete ownership question will encourage shares.

Approval: **not approved**. Sources: **not retrieved; verify before publication**.

A different brand name does not always mean a different owner. A roll-up is a strategy of acquiring multiple businesses, often in the same sector.

The competition question is what those acquisitions do to customers' and workers' real alternatives. Common ownership is a reason to investigate; it is not by itself proof of an unlawful monopoly.

The DOJ and FTC's 2023 Merger Guidelines discuss examining a pattern or strategy of multiple acquisitions. Guidelines are an analytical framework, not a court finding about any particular company.

Opinion: If your local choices are shrinking, the ownership map deserves attention.

Share this with someone who likes to know who owns the brands they use.

#Competition #PrivateEquity #ConsumerRights

Source reference (review before publishing):
https://www.justice.gov/atr/merger-guidelines

Before publication:

- [ ] Read Guideline 8 in the 2023 Merger Guidelines and confirm the description.
- [ ] The post describes a dated document, not a verified statement of current enforcement policy.
- [ ] Do not imply that all common ownership is private equity or that all roll-ups are unlawful.
- [ ] Review graphic, caption and final source links.
- [ ] Approve the final version and manually schedule it.

## Day 4 — Workers belong in the deal review.

Files: `04-w01-04.jpg`, `04-w01-04-caption.txt`

Format: worker_lens. Hypothesis: Including workers' concerns will prompt substantive comments.

Approval: **not approved**. Sources: **not retrieved; verify before publication**.

Merger debates should ask what a deal means for employees as well as customers.

The DOJ and FTC's 2023 Merger Guidelines include an analysis of mergers between competing buyers, including employers buying workers' labor. That is an analytical framework, not a finding that any particular deal harmed employees.

Opinion: A deal's success should include pay, staffing, working conditions and meaningful job alternatives—not only an investor return.

A useful before-and-after checklist: wages, benefits, hours, turnover and staffing. Check other explanations before attributing a change to ownership.

What would you add to that checklist? Please avoid sharing confidential information or naming individual coworkers.

#WorkersRights #Competition #PrivateEquity

Source reference (review before publishing):
https://www.justice.gov/atr/merger-guidelines

Before publication:

- [ ] Read Guideline 10 in the 2023 Merger Guidelines and confirm the employer/labor description.
- [ ] This describes the 2023 text, not independently verified current policy.
- [ ] Do not imply that this checklist is evidence of harm at a named company.
- [ ] Review graphic, caption and final source links.
- [ ] Approve the final version and manually schedule it.

## Day 5 — After the buyout isn't proof of because of the buyout.

Files: `05-w01-05.jpg`, `05-w01-05-caption.txt`

Format: evidence_checklist. Hypothesis: A useful research checklist will produce saves and establish the account's editorial approach.

Approval: **not approved**. Sources: editorial / methodological draft; no external factual example asserted.

A price increase, closure or staffing cut after an acquisition deserves scrutiny. Timing alone does not establish the cause.

Here is the evidence checklist we want to use:
1. Confirm the owner and acquisition date.
2. Document what changed and when.
3. Read financial filings or other primary records.
4. Consider competing explanations.
5. Separate allegations, research findings and opinion.

Opinion: Criticism of private equity is stronger when it can survive a fact check.

Save this for your next research session. If we get something wrong, send the supporting source so we can correct it.

#MediaLiteracy #PrivateEquity #FollowTheMoney

Before publication:

- [ ] This is a proposed research method, not a report on a specific acquisition.
- [ ] Provide a working correction channel in the profile before using the call to action.
- [ ] Review graphic, caption and final source links.
- [ ] Approve the final version and manually schedule it.

## Day 6 — A successful exit. A better business for whom?

Files: `06-w01-06.jpg`, `06-w01-06-caption.txt`

Format: editorial_question. Hypothesis: A clear value statement will generate relevant profile visits and follows.

Approval: **not approved**. Sources: editorial / methodological draft; no external factual example asserted.

Opinion: An investor's successful exit is not the only scorecard that matters.

When an owner sells a business, we should also ask what happened to service quality, affordability, employee pay, business investment and customers' alternatives.

Sometimes those outcomes improve. Sometimes they do not. The point is to investigate the actual record rather than treat the sale price as the whole story.

Our position: ordinary customers and employees belong in the assessment of a buyout.

Which measure would you check first—and why?

#PrivateEquity #WorkersRights #ConsumerRights

Before publication:

- [ ] Keep this explicitly labeled as opinion.
- [ ] No statistics or company-specific claims are asserted.
- [ ] Review graphic, caption and final source links.
- [ ] Approve the final version and manually schedule it.

## Day 7 — Which industry should we investigate next?

Files: `07-w01-07.jpg`, `07-w01-07-caption.txt`

Format: audience_research. Hypothesis: A specific choice will identify an audience interest for week two.

Approval: **not approved**. Sources: editorial / methodological draft; no external factual example asserted.

Help choose our next evidence-led private equity explainer.

A. Healthcare and patient care
B. Housing and tenant costs
C. Everyday services and local competition
D. Another industry: tell us which one

We are looking for a question we can investigate with records and reliable sources. A personal experience can be a useful lead; it is not enough on its own to establish who caused a problem.

Tell us the question you want answered. Please leave out personal data, confidential documents and accusations about individual employees.

Opinion: People affected by business decisions deserve a place in the conversation.

#PrivateEquity #ConsumerRights #WorkersRights

Before publication:

- [ ] Do not imply that any listed industry is uniformly controlled by private equity.
- [ ] Review comments before turning a personal story into a published factual claim.
- [ ] Review graphic, caption and final source links.
- [ ] Approve the final version and manually schedule it.
