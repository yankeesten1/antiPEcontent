# Introduction redesign — draft, not approved

The carousel and reel are alternative versions of the SAME introduction. Choose one first; do not post both back-to-back as different stories.

- Carousel: upload carousel-01.jpg through carousel-05.jpg in numbered order as one Instagram multi-image post. Each is 1080×1350.
- Reel (if included): introduction-reel.mp4 is a 20-second, 1080×1920 H.264 video at 24 fps. It has motion, fades and on-screen text, but no audio track. Add your own voiceover using optional-voiceover.txt or choose audio you have rights to use in Instagram's editor. The text is understandable on mute.
- Use caption.txt, review the exact images/video and approve the final version before posting. This is an editorial introduction, not evidence about a named company. No statistics, fake customer quotes or company-specific allegations are asserted.
- This replaces the plain first-post concept as a proposed visual direction. The rest of the week's content has not yet been redesigned or source-verified. Nothing has been scheduled or published.
- Once account access returns, inspect Instagram's crop and interface overlays before posting. Motion and brighter graphics do not guarantee reach. Compare several posts before deciding which format works.

First-frame hook: “Your town. Their exit plan?” The five-card story asks who benefits, identifies research questions, states the evidence standard, and invites a topic choice.
