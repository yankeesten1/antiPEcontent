# Replacement cut: fixed frames, local neural voice and arranged music

This supersedes the rejected Flite/zoom preview. Nothing is approved or published.

- introduction-audio-preview.mp4: the new narrated cut, using local Kokoro / af_sarah. The five scenes are stationary with clean cuts; there is no zoom, pan or scale animation.
- music-only-preview.mp4: identical visuals with the new soundtrack alone, for an easy music check.
- introduction-reel.mp4: silent counterpart.
- narration-preview.wav and music-original.wav: source stems. The MP4 mix normalizes and processes these tracks.
- narration-captions.srt and voiceover-timing.json: actual subtitles and scene timings.
- carousel-01.jpg to carousel-05.jpg: the five-card alternative; upload these as one carousel if chosen.
- caption.txt: current introduction caption. This is a style/audio review, not a completed case investigation.

The neural voice runs locally: no paid service, API key or per-minute speech API bill. See VOICE-SOURCES.md for provenance, license references, exact model digests and repeatable setup. Models are not bundled in this ZIP.

Technical checks on this cut: 1080x1920 H.264, 24 fps, stereo AAC, about 20.83 seconds; decoded frames sampled twice per scene remain stationary. Mixed audio measures about -16.5 LUFS with true peak about -3.1 dBFS. Music-only comparison measures about -19 LUFS. These measurements do not substitute for your listening review. Tell us whether the voice style, music choice and level suit the account before approval.

Case-specific factual reporting remains subject to source retrieval, quote checks and final editorial approval. The original opinion cards and rejected audio ZIPs are archival prototypes.
