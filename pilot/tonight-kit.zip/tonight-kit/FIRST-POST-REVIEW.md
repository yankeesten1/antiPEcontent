# First post — ready for your review, not approved

Graphic: `01-w01-01.jpg`

This introduction states an editorial position. It makes no company-specific allegations and does not depend on the blocked source pages.

Opinion: A business should be judged by how it serves customers and treats workers—not just the price its owners can sell it for.

That is the question behind this account: when investors buy a business, who benefits, who takes the risk, and what happens to the people who depend on it?

We will scrutinize private equity using documents, clear explanations and corrections when the evidence changes. An acquisition alone does not prove wrongdoing.

What industry should we examine first: housing, healthcare or everyday services?

#PrivateEquity #WorkersRights #ConsumerRights

Before publishing: confirm the display name/handle, preview the actual graphic and caption, choose whether to revise the wording, then explicitly approve the final version. Scheduling and account access are still pending.
