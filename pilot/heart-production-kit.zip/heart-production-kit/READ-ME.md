# Introduction redesign — draft, not approved

The carousel and reel are alternative versions of the SAME introduction. Choose one first; do not post both back-to-back as different stories.

- Carousel: upload carousel-01.jpg through carousel-05.jpg in numbered order as one Instagram multi-image post. Each is 1080×1350.
- Reel (if included): introduction-reel.mp4 uses stationary 1080×1920 frames, clean cuts and no zoom/pan animation, at 24 fps. It has no audio track. Silent-only exports are 20 seconds; an audio preview extends scene timing as needed.
- Audio preview (if included): introduction-audio-preview.mp4 adds local neural narration (see voice-settings.json for the chosen voice/speed) and an original arranged instrumental. music-only-preview.mp4 is a separate soundtrack check. These are new review cuts, not approved final posts. narration-preview.wav and music-original.wav are separate tracks. No paid voice API, witness/company recording or sampled song is used. Model provenance and licenses are documented in pilot/VOICE-SOURCES.md in the repository.
- Use caption.txt, review the exact images/video and approve the final version before posting. This is an editorial introduction, not evidence about a named company. No statistics, fake customer quotes or company-specific allegations are asserted.
- This replaces the plain first-post concept as a proposed visual direction. The rest of the week's content has not yet been redesigned or source-verified. Nothing has been scheduled or published.
- Once account access returns, inspect Instagram's crop and interface overlays before posting. Motion and brighter graphics do not guarantee reach. Compare several posts before deciding which format works.

First-frame hook: “Your town. Their exit plan?” The five-card story asks who benefits, identifies research questions, states the evidence standard, and invites a topic choice.
